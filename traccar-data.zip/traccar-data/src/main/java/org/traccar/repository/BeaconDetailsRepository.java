package org.traccar.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.traccar.entity.BeaconDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.StoredProcedureQuery;
import java.util.ArrayList;
import java.util.List;


@Repository
public class BeaconDetailsRepository {

    private final EntityManager entityManager;

    @Autowired
    public BeaconDetailsRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /**
     * Call stored procedure to extract beacons list
     */
    public List<BeaconDetails> extractBeaconsList() {
        try {
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery("get_device_beacons");
            query.execute();

            @SuppressWarnings("unchecked")
            List<Object[]> results = query.getResultList();

            return convertToBeacons(results);
        } catch (Exception e) {
            throw new RuntimeException("Failed to call extract_beacons_list stored procedure", e);
        }
    }

    /**
     * Alternative method using native query
     */
    public List<BeaconDetails> callExtractBeaconsList() {
        try {
            @SuppressWarnings("unchecked")
            List<Object[]> results = entityManager.createNativeQuery("CALL get_device_beacons()")
                    .getResultList();

            return convertToBeacons(results);
        } catch (Exception e) {
            throw new RuntimeException("Failed to call extract_beacons_list using native query", e);
        }
    }

    /**
     * Helper method to convert Object[] results to Beacon objects
     */
    private List<BeaconDetails> convertToBeacons(List<Object[]> results) {
        List<BeaconDetails> beacons = new ArrayList<>();

        for (Object[] row : results) {
            BeaconDetails beacon = new BeaconDetails(
                    row[0] != null ? Long.parseLong(row[0].toString()): null,      // deviceid
                    row[1] != null ? row[1].toString() : null,                  // devicename
                    row[2] != null ? row[2].toString() : null,                  // servertime
                    row[3] != null ? row[3].toString() : null,                  // beacon_key
                    row[4] != null ? row[4].toString() : null,                  // beaconUuid
                    row[5] != null ? row[5].toString() : null,                  // beaconName
                    row[6] != null ? row[6].toString() : null,                  // beaconPersonName
                    row[7] != null ? Integer.parseInt(row[7].toString()): null,       // beaconMajor
                    row[8] != null ? Integer.parseInt(row[8].toString()) : null,       // beaconMinor
                    row[9] != null ? Integer.parseInt(row[8].toString()): null,       // beaconRssi
                    row[10] != null ? Double.parseDouble(row[10].toString()): null     // beaconBattery
            );
            beacons.add(beacon);
        }

        return beacons;
    }
}
