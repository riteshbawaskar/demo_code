package org.traccar.service;

import org.traccar.entity.BeaconDetails;
import org.traccar.repository.BeaconDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class BeaconDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(BeaconDetailsService.class);

    private final BeaconDetailsRepository beaconRepository;
    private final EntityManager entityManager;

    @Autowired
    public BeaconDetailsService(BeaconDetailsRepository beaconRepository, EntityManager entityManager) {
        this.beaconRepository = beaconRepository;
        this.entityManager = entityManager;
    }

    /**
     * Get all beacons by calling the stored procedure
     */
    public List<BeaconDetails> getBeaconsList() {
        try {
            logger.info("Calling extract_beacons_list stored procedure");

            // Try using the named query first
            try {
                List<BeaconDetails> beacons = beaconRepository.extractBeaconsList();
                logger.info("Successfully retrieved {} beacons using named query", beacons.size());
                return beacons;
            } catch (Exception e) {
                logger.warn("Named query failed, trying alternative approach: {}", e.getMessage());

                // Fallback to EntityManager approach
                return getBeaconsUsingEntityManager();
            }

        } catch (Exception e) {
            logger.error("Error calling extract_beacons_list stored procedure", e);
            throw new RuntimeException("Failed to retrieve beacons list", e);
        }
    }

    /**
     * Alternative method using EntityManager for stored procedure call
     */
    public List<BeaconDetails> getBeaconsUsingEntityManager() {
        try {
            logger.info("Calling stored procedure using EntityManager");

            StoredProcedureQuery query = entityManager.createStoredProcedureQuery("get_device_beacons");

            // Execute the stored procedure
            query.execute();

            // Get the result list
            @SuppressWarnings("unchecked")
            List<Object[]> results = query.getResultList();

            // Convert Object[] to Beacon objects
            List<BeaconDetails> beacons = new ArrayList<>();
            for (Object[] row : results) {
                BeaconDetails beacon = new BeaconDetails(
                        row[0] != null ? Long.parseLong(row[0].toString()): null,      // deviceid
                        row[1] != null ? row[1].toString() : null,                  // devicename
                        row[2] != null ? row[2].toString() : null,                  // servertime
                        row[3] != null ? row[3].toString() : null,                  // beacon_key
                        row[4] != null ? row[4].toString() : null,                  // beaconUuid
                        row[5] != null ? row[5].toString() : null,                  // beaconName
                        row[6] != null ? row[6].toString() : null,                  // beaconPersonName
                        row[7] != null ? Integer.parseInt(row[7].toString()): null,       // beaconMajor
                        row[8] != null ? Integer.parseInt(row[8].toString()) : null,       // beaconMinor
                        row[9] != null ? Integer.parseInt(row[8].toString()): null,       // beaconRssi
                        row[10] != null ? Double.parseDouble(row[10].toString()): null
                );
                beacons.add(beacon);
            }

            logger.info("Successfully retrieved {} beacons using EntityManager", beacons.size());
            return beacons;

        } catch (Exception e) {
            logger.error("Error calling stored procedure using EntityManager", e);
            throw new RuntimeException("Failed to retrieve beacons list using EntityManager", e);
        }
    }
}
