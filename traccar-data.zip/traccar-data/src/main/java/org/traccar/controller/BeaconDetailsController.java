package org.traccar.controller;

import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.traccar.entity.BeaconDetails;
import org.traccar.service.BeaconDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/beacondetails")
@CrossOrigin(origins = "*")
public class BeaconDetailsController {

    private static final Logger logger = LoggerFactory.getLogger(BeaconDetailsController.class);

    private final BeaconDetailsService beaconService;

    @Autowired
    public BeaconDetailsController(BeaconDetailsService beaconService) {
        this.beaconService = beaconService;
    }

    /**
     * Get all beacons by calling the stored procedure extract_beacons_list
     */
    @GetMapping

    public ResponseEntity<List<BeaconDetails>> getBeaconsList() {
        try {
            logger.info("API call: GET /beacons - Getting all beacons");

            List<BeaconDetails> beacons = beaconService.getBeaconsList();

            logger.info("Successfully retrieved {} beacons", beacons.size());
            return ResponseEntity.ok(beacons);

        } catch (Exception e) {
            logger.error("Error retrieving beacons list", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Alternative endpoint name for backward compatibility
     */
    @GetMapping("/list")
    public ResponseEntity<List<BeaconDetails>> getBeaconsListAlias() {
        return getBeaconsList();
    }
}
