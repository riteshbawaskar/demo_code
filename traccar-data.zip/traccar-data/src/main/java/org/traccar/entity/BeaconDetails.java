package org.traccar.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Entity
@SqlResultSetMapping(
        name = "BeaconMapping",
        classes = @ConstructorResult(
                targetClass = BeaconDetails.class,
                columns = {
                       @ColumnResult(name = "deviceid", type = Long.class),
                        @ColumnResult(name = "device_name", type = String.class),
                        @ColumnResult(name = "server_time", type = String.class),
                        @ColumnResult(name = "beacon_key", type = String.class),
                        @ColumnResult(name = "beacon_uuid", type = String.class),
                        @ColumnResult(name = "beacon_name", type = String.class),
                        @ColumnResult(name = "beacon_person_name", type = String.class),
                        @ColumnResult(name = "beaconMajor", type = Integer.class),
                        @ColumnResult(name = "beaconMinor", type = Integer.class),
                        @ColumnResult(name = "beaconRssi", type = Integer.class),
                        @ColumnResult(name = "beaconBattery", type = Double.class)
                }
        )
)
@NamedNativeQuery(
        name = "traccar.get_device_beacons",
        query = "CALL get_device_beacons()",
        resultSetMapping = "BeaconMapping"
)
@Data
public class BeaconDetails {

    @Id
    private Long id;

    @JsonProperty("deviceId")
    private Long deviceId;

    @JsonProperty("deviceName")
    private String deviceName;

    @JsonProperty("serverTime")
    private String serverTime;

    @JsonProperty("beaconKey")
    private String beaconKey;

    @JsonProperty("beaconUuid")
    private String beaconUuid;

    @JsonProperty("beaconName")
    private String beaconName;

    @JsonProperty("beaconPersonName")
    private String beaconPersonName;

    @JsonProperty("beaconMajor")
    private Integer beaconMajor;

    @JsonProperty("beaconMinor")
    private Integer beaconMinor;

    @JsonProperty("beaconRssi")
    private Integer beaconRssi;

    @JsonProperty("beaconBattery")
    private Double beaconBattery;

    // Default constructor
    public BeaconDetails() {}

    // Constructor for stored procedure result mapping
    public BeaconDetails(Long deviceId, String deviceName, String Servertime,String beaconKey,
                  String beaconUuid, String beaconName, String beaconPersonName, Integer beaconMajor,
                  Integer beaconMinor, Integer beaconRssi, Double beaconBattery) {

        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.serverTime = Servertime;
        this.beaconKey = beaconKey;
        this.beaconUuid = beaconUuid;
        this.beaconName = beaconName;
        this.beaconPersonName = beaconPersonName;
        this.beaconMajor = beaconMajor;
        this.beaconMinor = beaconMinor;
        this.beaconRssi = beaconRssi;
        this.beaconBattery = beaconBattery;
    }

    @Override
    public String toString() {
        return "BeaconDetails{" +
                "id=" + id +
                ", deviceId=" + deviceId +
                ", deviceName='" + deviceName + '\'' +
                ", beaconKey='" + beaconKey + '\'' +
                ", beaconUuid='" + beaconUuid + '\'' +
                ", beaconName='" + beaconName + '\'' +
                ", beaconPersonName='" + beaconPersonName + '\'' +
                ", beaconMajor=" + beaconMajor +
                ", beaconMinor=" + beaconMinor +
                ", beaconRssi=" + beaconRssi +
                ", beaconBattery=" + beaconBattery +
                '}';
    }
}
