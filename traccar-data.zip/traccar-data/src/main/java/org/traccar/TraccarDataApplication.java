package org.traccar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableJpaRepositories
@EnableTransactionManagement
@EnableConfigurationProperties
public class TraccarDataApplication {

    public static void main(String[] args) {
        // Set system property for Windows service compatibility
        System.setProperty("java.awt.headless", "true");

        SpringApplication application = new SpringApplication(TraccarDataApplication.class);

        // Configure for service deployment
        application.setLogStartupInfo(true);
        application.setRegisterShutdownHook(true);

        application.run(args);
    }
}